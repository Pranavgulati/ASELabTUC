#define LED0 SIU.GPDO[9].R
#define LED1 SIU.GPDO[42].R
#define LED2 SIU.GPDO[13].R
#define LED3 SIU.GPDO[12].R
#define LED4 SIU.GPDO[62].R
#define LED5 SIU.GPDO[61].R   
#define LED6 SIU.GPDO[59].R
#define LED7 SIU.GPDO[11].R

#define BT6 SIU.GPDI[0].R
#define BT5 SIU.GPDI[1].R
#define SW4 SIU.GPDI[2].R
#define SW3 SIU.GPDI[3].R
#define SW2 SIU.GPDI[4].R 
#define SW1 SIU.GPDI[44].R

#define IN1 ADC_0.CDR[2].B.CDATA
#define POT ADC_0.CDR[4].B.CDATA
#define TMP ADC_0.CDR[5].B.CDATA