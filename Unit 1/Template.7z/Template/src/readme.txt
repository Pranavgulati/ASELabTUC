!!!!!!!!!!!!!!!!!!!!!!
!!! IMPORTANT NOTE !!!
!!!!!!!!!!!!!!!!!!!!!!


The WindRiver compile chain executables need
some environment properties to be set for working properly.
For this, WindRiver provides a Development Shell and a shortcut to it,
which are installed along with the compiler.

In order to use Ride with this compiler,
you must start Ride from the WindRiver Development Shell:

1. Install both Ride7 and the WindRiver compiler (and your license file(s)).
2. Start the WindRiver Development Shell.
3. Execute the "Ride7.exe" command from this shell.

Then Ride will be able to call the WindRiver executables.


